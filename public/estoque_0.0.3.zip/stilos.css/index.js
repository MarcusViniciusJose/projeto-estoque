// Aguarda o carregamento completo da página
document.addEventListener("DOMContentLoaded", function () {

    const botao = document.getElementById("loginbtn");

    botao.addEventListener("click", login);

});

function login() {

    const email = document.getElementById("username").value.trim();
    const senha = document.getElementById("password").value.trim();

    // Validação de campos vazios
    if (email === "" || senha === "") {
        document.getElementById("resultado").innerHTML = "Preencha todos os campos!";
        return 0;
    }

    // Login teste
    if (email === "kahua@gmail.com" && senha === "@kahua1105") {

        window.location.href = "dashbord.html";

    } else {
        document.getElementById("resultado").innerHTML = "Email ou senha incorretos!";
    }
    

}
  
   // dashbord funcoes 

   function telaCadastro(){
    window.location.href = "cadastro.html";
   }

   function telaInicio() {
    window.location.href = "dashbord.html";
}
   function telaEntradaEsaidas(){
    window.location.href ="entradasesaidas.html";
}
   function telaEstoque(){
    window.location.href ="estoque.html";
}