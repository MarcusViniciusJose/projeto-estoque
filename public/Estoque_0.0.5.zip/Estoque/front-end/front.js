// Aguarda o carregamento completo da página
document.addEventListener("DOMContentLoaded", function () {

    const botao = document.getElementById("loginbtn");

    botao.addEventListener("click", login);

});

function login() {

    const email = document.getElementById("username").value.trim();
    const senha = document.getElementById("password").value.trim();

    // Validação de campos vazios
    if (email === "" || senha === "") {
        document.getElementById("resultado").innerHTML = "Preencha todos os campos!";
        return 0;
    }

    // Login teste
    if (email === "kahua@gmail.com" && senha === "@kahua1105") {

        window.location.href = "dashbord.html";

    } else {
        document.getElementById("resultado").innerHTML = "Email ou senha incorretos!";
    }
    

}
  
   // dashbord funcoes 

   function telaCadastro(){
    window.location.href = "cadastro.html";
   }

   function telaInicio() {
    window.location.href = "dashbord.html";
}
   function telaEntradaEsaidas(){
    window.location.href ="entradasesaidas.html";
}
   function telaEstoque(){
    window.location.href ="estoque.html";
}
// funçao para sair da conta 
function sairConta(){
    window.location.href="index.html";
}
//backend
 fetch("http://localhost:3006/estoque/listar")
.then(res => res.json())
.then(dados => {

    console.log(dados);

});

//função para puxar produtos do banco
fetch("http://localhost:3006/produtos")
    .then(Response => Response.json())
    .then(data =>{
        const tabela = document.getElementById("listaEstoque");

        data.forEach(produto => {
            const linha= document.createElement("tr");
               linha.innerHTML = `
                 <td>${produto.id}</td>
                 <td>${produto.nome}</td>
                 <td>${produto.Quantidade}</td>
                 <td>${produto.Validade}</td>               
                 `;
                tabela.appendChild(linha);  
            });

    })
    .catch(error => console.error("ERRO AO CARREGAR PRODUTOS; ", error));

    fetch("http://localhost:3006/criarlogin"),{
      method: "post",
        Headers: {
            "Content-Type": "application/json"
        },
        body : JSON.stringify({
            email: email,
            senha: senha
        })
    }
    
    .then(res=> res.json())
    .then(data =>{
        console.log(data)
    });

    fetch("http://localhost:3006/produtos", {
    headers: {
        "Authorization": localStorage.getItem("token")
    }
})