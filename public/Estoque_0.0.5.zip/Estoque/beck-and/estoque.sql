CREATE DATABASE estoque;

USE estoque;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    confirmar_senha VARCHAR(100) NOT NULL UNIQUE,
     senha VARCHAR(255) NOT NULL,
);

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_produto VARCHAR(50) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    quantidade INT NOT NULL,
    validade DATE NOT NULL
);

