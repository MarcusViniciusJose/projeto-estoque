// conectando ao bando de dados mysql
const mysql = require('mysql2');
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password:'@Kahua1105',
    database: 'estoque',
});
connection.connect((err) => {
    if (err) {
        console.log("erro ao conectar com o banco de dados: ", err);
        return 0;
    }else{
        console.log("sucesso ao conectar com o banco de dados!");

    }    
});
// exportando a conecçao 
module.exports= connection;