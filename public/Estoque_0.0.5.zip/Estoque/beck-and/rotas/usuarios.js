//ROTA DE USUARIOS
const express= require('express');
    const router= express.Router();
    const db = require('../db');
    
router.post('/criar', (req, res) => {

     const {email, senha, confirmar_senha} = req.body;
    const sql = "INSERT INTO usuarios (email, senha, confirmar_senha ) VALUES (?,?,?)";
    db.query(sql, [ email, senha, confirmar_senha], (err, result) => {
        if(err){
            console.log("erro ao criar usuario:", err);
            res.status(500).json(err);
        }else{
            res.json("usuario criado");
        }
    });
});


router.get('/listar', (req, res) => {
    db.query("SELECT * FROM usuarios", (err, result) => {
        if(err){
            res.status(500).json(err);
        }else{
            res.json(result);
        }
    });
});

module.exports=router;
