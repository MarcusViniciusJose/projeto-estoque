//rota listar produtos 
const express= require('express');
    const router= express.Router();
    const db = require('../db');

    router.get('/listar', (req, res) => {
        db.query("SELECT * FROM ESTOQUE", (err, result) => {
            if (err) {
                console.error("Erro ao listar produtos: ", err);
                res.status(500).json(err);
            } else {
                res.json(result);
            }
        });
    });

    module.exports= router;
    