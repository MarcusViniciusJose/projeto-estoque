const express = require('express');
const router = express.Router();
const db= require('../db')
const bcrypt = require('bcrypt');

router.post('/criarlogin', async (req,res)=> {
  const {email,senha} = req.body;
    const senhaCriptografada= await bcrypt.hash(senha, 10);

    const sql= "INSERT INTO usuarios (email, senha) VALUES (?,?)";
      db.query(sql, [email, senhaCriptografada], (err)=>{
        if(err){ 
            return res.status(500).json(err);
            }
      
            res.json("login criado");
  
  });
});
 
module.exports=router;
