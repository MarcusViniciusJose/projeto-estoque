const express = require('express');
const router = express.Router();   
const db = require('../db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');


    router.post('/rotaDlogin', (req, res ) => {
       const {email, senha} = req.body;
       const sql = "SELECT *  FROM usuarios WHERE email = ?"
          
           db.query(sql, [email], async (err, result)=> {
              if(err)return res.status(500),json(err);
              
              if(result.length === 0 ){
                    return res.status(401).json({erro: "usuario nao encontrado"});
                    };

              
          
              const usuario = result[0];
              const senhaValida = await bcrypt.compare(senha,usuario.senha);
                 
                if(!senhaValida){
                    return res(500).json({error: "senha invalida"});
                } 

              const token = jwt.sign(
                 {id: usuario.id, email: usuario.email },
                 "segredo_super_secreto",
                 { expiresIn: "1h" } 
              );  

              res.token({ token });
             
        
        });
    
         
     });

     module.exports=router;