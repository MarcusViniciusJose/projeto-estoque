const express= require('express');
    const router= express.Router();
    const db = require('../db');

    router.post('/cadastrar', (req, res) =>{
        const {id, nome, quantidade, validade}= req.body;
        const sql = "INSERT INTO estoque (id_produto, nome, quantidade, validade) VALUES(?,?,?,?)";

        db.query(sql, [id, nome,quantidade,validade], (err, result)=>{
            if(err){
                res.status(500).json(err);
            }else{
                res.json("produto cadastrado");
            }
        });
    });
    router.get('/listar', (req, res) =>{
         db.query("SELECT * FROM estoque", (err, result)=> {
            if(err){
                res.status(500).json(err);
            } else{
                res.json(result);
            }
         });
    });

    module.exports= router;

   

