//server
const express= require('express');
const cors= require('cors');
const usuarios= require('./rotas/usuarios');
const estoque= require('./rotas/estoque');
const rotaDlogin= require('./rotas/rotaDlogin');
const criar = require('./rotas/criarLogin');
const app= express();

app.use(cors());
app.use(express.json());
app.use('/usuarios', usuarios);
app.use('/estoque', estoque);
app.use('/rotaDlogin', rotaDlogin);
app.use('/criarlogin', criar);

app.listen(3006, () =>{
    console.log("servidor rodando na porta 3000");

});

